package com.fibernetwork.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int LOCATION_REQ = 1001;
    private LocationManager locationManager;
    private boolean waitingForNativeLocation = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) callback.invoke(origin, true, false);
                else {
                    pendingOrigin = origin;
                    pendingCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
                }
            }
        });
        webView.addJavascriptInterface(new NativeLocation(), "AndroidLocation");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String pendingOrigin;
    private GeolocationPermissions.Callback pendingCallback;

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ) {
            boolean ok = hasLocationPermission();
            if (pendingCallback != null) {
                pendingCallback.invoke(pendingOrigin, ok, false);
                pendingCallback = null;
                pendingOrigin = null;
            }
            if (waitingForNativeLocation && ok) requestNativeLocation();
            else if (!ok) notifyJsError("Location permission দেওয়া হয়নি। Android Settings থেকে Location permission Allow করুন।");
        }
    }

    private void requestNativeLocation() {
        if (!hasLocationPermission()) {
            waitingForNativeLocation = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
            return;
        }
        waitingForNativeLocation = false;
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && !locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            notifyJsError("ফোনের Location/GPS বন্ধ আছে। আগে Location ON করুন।");
            return;
        }
        try {
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            criteria.setPowerRequirement(Criteria.POWER_HIGH);
            String provider = locationManager.getBestProvider(criteria, true);
            if (provider == null) provider = LocationManager.GPS_PROVIDER;
            final String selectedProvider = provider;
            Location last = locationManager.getLastKnownLocation(selectedProvider);
            if (last != null && System.currentTimeMillis() - last.getTime() < 120000) {
                sendLocationToJs(last);
                return;
            }
            locationManager.requestSingleUpdate(selectedProvider, new LocationListener() {
                @Override public void onLocationChanged(Location location) { sendLocationToJs(location); }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            }, getMainLooper());
            webView.postDelayed(() -> {
                try { locationManager.removeUpdates(new LocationListener() {
                    @Override public void onLocationChanged(Location location) {}
                    @Override public void onProviderEnabled(String provider) {}
                    @Override public void onProviderDisabled(String provider) {}
                }); } catch (Exception ignored) {}
            }, 30000);
        } catch (SecurityException e) {
            notifyJsError("Location permission পাওয়া যায়নি।");
        } catch (Exception e) {
            notifyJsError("GPS error: " + e.getMessage());
        }
    }

    private void sendLocationToJs(Location location) {
        final double lat = location.getLatitude();
        final double lng = location.getLongitude();
        final float acc = location.hasAccuracy() ? location.getAccuracy() : 0f;
        webView.post(() -> webView.evaluateJavascript("window.onNativeLocation(" + lat + "," + lng + "," + acc + ")", null));
    }

    private void notifyJsError(String message) {
        webView.post(() -> webView.evaluateJavascript("window.onNativeLocationError(" + jsQuote(message) + ")", null));
    }

    private String jsQuote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\"";
    }

    public class NativeLocation {
        @JavascriptInterface public void getCurrentLocation() {
            runOnUiThread(() -> requestNativeLocation());
        }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
